package com.Zoomanagement_backend.Repository;

import com.Zoomanagement_backend.Entity.Type;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TypeRepo extends JpaRepository<Type,Integer> {
}
